#!/bin/bash

function color_selection {
    export dc="\033[0m" # Очистка форматирования

    color_check $1
    export bc1="\033[4$?m" # Цвет фона 1 столбца 

    color_check $2
    export tc1="\033[3$?m" # Цвет текста 1 столбца

    color_check $3
    export bc2="\033[4$?m" # Цвет фона 2 столбца

    color_check $4
    export tc2="\033[3$?m" # Цвет текста 2 столбца
}

function color_check {
    case "$1" in
        "1" )
            return 7;; # white
        "2" )
            return 1;; # red
        "3" )
            return 2;; # green
        "4" )
            return 4;; # blue
        "5" )
            return 5;; # violet
        "6" )
            return 0;; # black
    esac
}
