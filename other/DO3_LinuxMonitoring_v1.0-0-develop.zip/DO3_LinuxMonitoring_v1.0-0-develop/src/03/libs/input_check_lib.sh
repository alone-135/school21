#!/bin/bash

function input_check {
    temp='^[1-6]\s[1-6]\s[1-6]\s[1-6]$'

    if ! [[ "$*" =~ $temp ]]; then
        echo "ERROR!" >&2
        exit 1
    else
        similar_options_check $*
    fi
}

function similar_options_check {
    if [ $1 = $2 ] || [ $3 = $4 ]; then
        echo "ERROR! - BACKGROUNG COLOR AND TEXT COLOR CANNOT BE THE SAME!" >&2
        exit 1
    fi
}
