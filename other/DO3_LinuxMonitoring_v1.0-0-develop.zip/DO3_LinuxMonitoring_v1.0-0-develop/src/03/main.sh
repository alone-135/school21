#!/bin/bash

. ./libs/input_check_lib.sh
. ./libs/color_selection_lib.sh
. ./libs/info_lib.sh

input_check $* # Проверка операторов
color_selection $* # Установка цветов
info_get # Получение данных
info_output # Вывод данных
