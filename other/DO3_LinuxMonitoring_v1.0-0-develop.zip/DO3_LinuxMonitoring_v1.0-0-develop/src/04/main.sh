#!/bin/bash

# Подключение библиотек
. ./libs/input_check_lib.sh
. ./libs/color_selection_lib.sh
. ./libs/info_lib.sh

# Обработка
input_check $* # Проверка на наличие операторов
color_selection # Установка цветов
info_get # Получение данных

# Вывод
echo
info_output # Вывод данных
echo
print_color # Вывод цветов
echo