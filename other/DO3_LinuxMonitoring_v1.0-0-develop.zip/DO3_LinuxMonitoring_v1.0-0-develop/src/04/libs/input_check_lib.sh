#!/bin/bash

# Проверка на наличие операторов
function input_check {
    if ! [[ "$#" = 0 ]]; then
        echo "ERROR!" >&2
        exit 1
    fi
}
