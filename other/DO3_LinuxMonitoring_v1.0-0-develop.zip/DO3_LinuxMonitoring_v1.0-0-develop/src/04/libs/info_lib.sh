#!/bin/bash

# Получение и подготовка информации о системе
function info_get {
    ram0=`free | grep Mem | awk '{print $2}'`; ram_t=`echo "scale=3; $ram0 / 1048576" | bc`
    ram1=`free | grep Mem | awk '{print $3}'`; ram_u=`echo "scale=3; $ram1 / 1048576" | bc`
    ram2=`free | grep Mem | awk '{print $4}'`; ram_f=`echo "scale=3; $ram2 / 1048576" | bc`

    rom0=`df / | grep / | awk '{print $2}'`; rom_t=`echo "scale=2; $rom0 / 1024" | bc`
    rom1=`df / | grep / | awk '{print $3}'`; rom_u=`echo "scale=2; $rom1 / 1024" | bc`
    rom2=`df / | grep / | awk '{print $4}'`; rom_f=`echo "scale=2; $rom2 / 1024" | bc`

    HOSTNAME=`hostname`
    TIMEZONE=`timedatectl | grep "Time zone" | sed -e 's/^[[:space:]]*Time zone: //;s///'`
    USER=`whoami`
    OS=`cat /etc/issue | grep Ubuntu | awk '{print $1" "$2" "$3}'`
    DATE=`date +%d\ %h\ %Y\ %H:%M:%S`
    UPTIME=`awk '{print int($1/3600)":"int(($1%3600)/60)":"int($1%60)}' /proc/uptime`
    UPTIME_SEC=`awk '{print int($1)}' /proc/uptime`
    IP=`hostname -I | awk '{print $1}'`
    MASK=`ifconfig | grep netmask | grep -v 127.0.0.1 | awk '{print $4}'`
    GATEWAY=`ip r | grep default | awk '{print $3}'`
    RAM_TOTAL="`printf "%.3f" $ram_t` GB"
    RAM_USED="`printf "%.3f" $ram_u` GB"
    RAM_FREE="`printf "%.3f" $ram_f` GB"
    SPACE_ROOT="`printf "%.2f" $rom_t` MB"
    SPACE_ROOT_USED="`printf "%.2f" $rom_u` MB"
    SPACE_ROOT_FREE="`printf "%.2f" $rom_f` MB"
}

# Печать информации с заданными настройками цветов
function info_output {
    echo -e "${bc1}${tc1}HOSTNAME${dc} = ${bc2}${tc2}${HOSTNAME}${dc}"
    echo -e "${bc1}${tc1}TIMEZONE${dc} = ${bc2}${tc2}${TIMEZONE}${dc}"
    echo -e "${bc1}${tc1}USER${dc} = ${bc2}${tc2}${USER}${dc}"
    echo -e "${bc1}${tc1}OS${dc} = ${bc2}${tc2}${OS}${dc}"
    echo -e "${bc1}${tc1}DATE${dc} = ${bc2}${tc2}${DATE}${dc}"
    echo -e "${bc1}${tc1}UPTIME${dc} = ${bc2}${tc2}${UPTIME}${dc}"
    echo -e "${bc1}${tc1}UPTIME_SEC${dc} = ${bc2}${tc2}${UPTIME_SEC}${dc}"
    echo -e "${bc1}${tc1}IP${dc} = ${bc2}${tc2}${IP}${dc}"
    echo -e "${bc1}${tc1}MASK${dc} = ${bc2}${tc2}${MASK}${dc}"
    echo -e "${bc1}${tc1}GATEWAY${dc} = ${bc2}${tc2}${GATEWAY}${dc}"
    echo -e "${bc1}${tc1}RAM_TOTAL${dc} = ${bc2}${tc2}${RAM_TOTAL}${dc}"
    echo -e "${bc1}${tc1}RAM_USED${dc} = ${bc2}${tc2}${RAM_USED}${dc}"
    echo -e "${bc1}${tc1}RAM_FREE${dc} = ${bc2}${tc2}${RAM_FREE}${dc}"
    echo -e "${bc1}${tc1}SPACE_ROOT${dc} = ${bc2}${tc2}${SPACE_ROOT}${dc}"
    echo -e "${bc1}${tc1}SPACE_ROOT_USED${dc} = ${bc2}${tc2}${SPACE_ROOT_USED}${dc}"
    echo -e "${bc1}${tc1}SPACE_ROOT_FREE${dc} = ${bc2}${tc2}${SPACE_ROOT_FREE}${dc}"
}