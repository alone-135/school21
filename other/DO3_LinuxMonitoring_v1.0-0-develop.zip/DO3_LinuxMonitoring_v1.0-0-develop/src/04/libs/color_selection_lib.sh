#!/bin/bash

# Обработка значений из файла
function color_selection {
    export dc="\033[0m" # Очистка форматирования
    temp='^[1-6]$' # Шаблон значения цвета
    count=0 # Счётчик линий

    for line in `cat color.conf`; 
    do
        count=$[ $count + 1 ]
        color_num=`echo "$line" | awk -F= '{print $2}'`

        if ! [[ "$color_num" =~ $temp ]]; then # Проверка на корректность заданных значений
            set_default_color # Задание значений по умолчанию
            break
        fi

        case "$count" in 
            "1" )
                get_color $color_num
                export bc1="\033[4$?m" # Цвет текста 1 столбца
                export bcn1="$cn";;
            "2" )
                get_color $color_num
                export tc1="\033[3$?m" # Цвет текста 1 столбца
                export tcn1="$cn";;
            "3" )
                get_color $color_num
                export bc2="\033[4$?m" # Цвет фона 2 столбца
                export bcn2="$cn";;
            "4" )
                get_color $color_num
                export tc2="\033[3$?m" # Цвет текста 2 столбца
                export tcn2="$cn";;
        esac       
    done
}

# Преобразование пользовательских значений в страндартные
function get_color {
    case "$1" in
        "1" )
            export cn="1 (white)"
            return 7;; # white
        "2" )
            export cn="2 (red)"
            return 1;; # red
        "3" )
            export cn="3 (green)"
            return 2;; # green
        "4" )
            export cn="4 (blue)"
            return 4;; # blue
        "5" )
            export cn="5 (violet)"
            return 5;; # violet
        "6" )
            export cn="6 (black)"
            return 0;; # black
    esac
}

# Печать образца
function example { 
    dc="\033[0m"
    for (( i = 1; i < 7; i++))
    do
        for (( j = 1; j < 7; j++))
        do
            get_color $i
            bc="\033[4$?m"
            bcn="$cn"
            get_color $j
            tc="\033[3$?m"
            tcn="$cn"
            
            echo -e "${bc}${tc}alone${dc} \t $bcn \t $tcn"
        done
    done
}

# Печать заданных цветов
function print_color {
    echo "Column 1 background = ${bcn1}"
    echo "Column 1 font color = ${tcn1}"
    echo "Column 2 background = ${bcn2}"
    echo "Column 2 font color = ${tcn2}"
}

# Задание значений по умолчанию
function set_default_color {
    get_color 6
    export bc1="\033[4$?m"
    get_color 3
    export tc1="\033[3$?m"
    get_color 6
    export bc2="\033[4$?m"
    get_color 4
    export tc2="\033[3$?m"
    export bcn1="default (black)"
    export tcn1="default (green)"
    export bcn2="default (black)"
    export tcn2="default (blue)"
}