#!/bin/bash

. ./libs/color_selection_lib.sh

example