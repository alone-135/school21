#!/bin/bash

temp='^[+-]?[0-9]+([.][0-9]+)?$'

if [ "$#" -gt 1 ]; then
    echo "ERROR! - TOO MANY OPTIONS! (MAX 1 OPTION)"
elif [ "$#" -eq 0 ]; then
    echo "EROOR! - TOO FEW OPTIONS! (MIN 1 OPTION)"
elif [[ $1 =~ $temp ]]; then
    echo "ERROR! - PARAMETER CANNOT BE A NUMBER!"
else
    echo "$1"
fi