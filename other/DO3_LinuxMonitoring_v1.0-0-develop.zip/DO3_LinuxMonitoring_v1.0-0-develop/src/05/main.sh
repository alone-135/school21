#!/bin/bash

. ./libs/check_options_lib.sh
. ./libs/info_lib.sh

check_options $* # Проверка оператора
prepare_info $1 # Подготовка информации
print_info $1 # Вывод информации