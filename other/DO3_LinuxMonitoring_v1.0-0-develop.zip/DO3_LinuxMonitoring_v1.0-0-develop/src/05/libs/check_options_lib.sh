#!/bin/bash

# Проверка оператора
function check_options {
    temp='^((\/)?(\.\.?)?(\/)?\.?(\w+)\/)+$' # Шаблон проверки пути
    root_dir='^\/$'
    
    if [ "$#" -gt 1 ] || [ "$#" -lt 1 ] || (! [[ "$1" =~ $temp ]] && [[ "$1" =~ $root_dir ]]); then  
        echo "ERROR!" >&2
        exit 1
    fi

    check_dir $1
}

# Проверка на наличие дериктории
function check_dir {
    if ! [ -d $1 ]; then
        echo "ERROR!" >&2
        exit 1
    fi
}