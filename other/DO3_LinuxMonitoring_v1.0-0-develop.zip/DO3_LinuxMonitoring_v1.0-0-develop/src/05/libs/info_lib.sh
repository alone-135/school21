#!/bin/bash

function prepare_info {
    export start_time=`date +%s`
    
    # Общее количество папок
    dir_count_f $1

    # Общее количество файлов
    files_count_f $1

    # Количество файлов по форматам
    files_stat_f $1
}

function print_info {
    echo "Total number of folders (including all nested ones) = "$dir_count""
    echo "TOP 5 folders of maximum size arranged in descending order (path and size):"
    top5_dir $1
    echo "Total number of files = "$files_count""
    echo "Number of:"
    echo "Configuration files (with the .conf extension) = "$conf_count""
    echo "Text files = "$text_count""
    echo "Executable files = "$exe_count""
    echo "Log files (with the extension .log) = $log_count"
    echo "Archive files = "$arch_count""
    echo "Symbolic links = "$links_count""
    echo "TOP 10 files of maximum size arranged in descending order (path, size and type):"
    top10_file $1
    echo "TOP 10 executable files of the maximum size arranged in descending order (path, size and MD5 hash of file)"
    top10_exe $1

    end_time=`date +%s`
    fi_time=$(($end_time - $start_time))
    echo "Script execution time (in seconds) = $fi_time"

}

function dir_count_f {
    export dir_count=`ls -laR $1 | grep "^d" | grep -v "\.$" | wc | sed 's/^\s*//' | awk '{print $1}'`
}


function files_count_f {
    export files_count=`ls -laR $1 | grep "^-" | grep -v "\.$" | wc | sed 's/^\s*//' | awk '{print $1}'`
}

function files_stat_f {
    conf_count=0
    text_count=0
    exe_count=0
    log_count=0
    arch_count=0
    links_count=0

    conf_count=`ls -laR $1 | grep "^-..*\.conf$" | wc -l`    
    log_count=`ls -laR $1 | grep "^-..*\.log$" | wc -l`    
    links_count=`ls -laR $1 | grep "^l" | wc -l`
    text_count=`ls -laR $1 | grep "^-..*\.txt$" | wc -l`
    exe_count=`ls -laR $1 | grep "^-........x" | wc -l`
    arch_count=`ls -laR $1 | grep -e ".tar$" \
                                    -e "^-..*\.gz$" \
                                    -e "^-..*\.zip$" \
                                    -e "^-..*\.iso$" \
                                    -e "^-..*\.7z$" \
                                    -e "^-..*\.arj$" \
                                    -e "^-..*\.rar$" | wc -l`
  
}

function top5_dir {
    i=1
    for ((var=1; var<6; var++, i++))
    do
        name=$(du -b $1 | grep -v "$1$" | sort -nr | head -5 | sed -n "$var"p | awk '{print $2}')
        size=$(du -b $1 | grep -v "$1$" | sort -nr | head -5 | sed -n "$var"p | awk '{print $1}')
        if ! [ -z "$name" ] && ! [ -z "$size" ] ; then
            echo "$i - $name, $(( $size / 1024 )) Kb"
        fi
    done
}

function top10_file {
    i=1
    for ((var=1; var<11; var++, i++))
    do
        name=$(find $1 -type f -printf '%s\t%p\n' | sort -nr | head -10 | sed -n "$var"p | awk '{print $2}')
        size=$(find $1 -type f -printf '%s\t%p\n' | sort -nr | head -10 | sed -n "$var"p | awk '{print $1}')
        if ! [ -z "$name" ] && ! [ -z "$size" ] ; then
            echo "$i - $name, $(( $size / 1024 )) Kb, ${name##*.}"
        fi
    done
}

function top10_exe {
    i=1
    for ((var=1; var<11; var++, i++))
    do
        name=$(find $1 -executable -type f -printf '%s\t%p\n' | sort -nr | head -10 | sed -n "$var"p | awk '{print $2}')
        size=$(find $1 -executable -type f -printf '%s\t%p\n' | sort -nr | head -10 | sed -n "$var"p | awk '{print $1}')
        hash=$(find $1 -executable -type f -printf "%s\t%p\t" -exec bash -c 'md=$(md5sum "$0"); echo ${md:0:32};' {} \; | sort -nr | head -10 | sed -n "$var"p | awk '{print $3}')
        if ! [ -z "$name" ] && ! [ -z "$size" ] && ! [ -z "$hash" ] ; then
            echo "$i - $name, $(( $size / 1024 )) Kb, $hash"
        fi
    done
}