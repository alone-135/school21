#!/bin/bash

ram0=`free | grep Mem | awk '{print $2}'`; ram_t=`echo "scale=3; $ram0 / 1048576" | bc`
ram1=`free | grep Mem | awk '{print $3}'`; ram_u=`echo "scale=3; $ram1 / 1048576" | bc`
ram2=`free | grep Mem | awk '{print $4}'`; ram_f=`echo "scale=3; $ram2 / 1048576" | bc`

rom0=`df / | grep / | awk '{print $2}'`; rom_t=`echo "scale=2; $rom0 / 1024" | bc`
rom1=`df / | grep / | awk '{print $3}'`; rom_u=`echo "scale=2; $rom1 / 1024" | bc`
rom2=`df / | grep / | awk '{print $4}'`; rom_f=`echo "scale=2; $rom2 / 1024" | bc`

exec > temp

echo "HOSTNAME = `hostname`" 
echo "TIMEZONE = `timedatectl | grep "Time zone" | sed -e 's/^[[:space:]]*Time zone: //;s///'`"
echo "USER = `whoami`"
echo "OS = `cat /etc/issue | grep Ubuntu | awk '{print $1" "$2" "$3}'`"
echo "DATE = `date +%d\ %h\ %Y\ %H:%M:%S`"
echo "UPTIME = `awk '{print int($1/3600)":"int(($1%3600)/60)":"int($1%60)}' /proc/uptime`"
echo "UPTIME_SEC = `awk '{print int($1)}' /proc/uptime`"
echo "IP = `hostname -I | awk '{print $1}'`"
echo "MASK = `ifconfig | grep netmask | grep -v 127.0.0.1 | awk '{print $4}'`"
echo "GATEWAY = `ip r | grep default | awk '{print $3}'`"
echo "RAM_TOTAL = `printf "%.3f" $ram_t` GB"
echo "RAM_USED = `printf "%.3f" $ram_u` GB"
echo "RAM_FREE = `printf "%.3f" $ram_f` GB"
echo "SPACE_ROOT= `printf "%.2f" $rom_t` MB"
echo "SPACE_ROOT_USED= `printf "%.2f" $rom_u` MB"
echo "SPACE_ROOT_FREE= `printf "%.2f" $rom_f` MB"

exec > /dev/tty

echo
cat temp
echo

read -p "Want to save the data to a file? (y or n): " answer

if [ "$answer" = "y" ] || [ "$answer" = "Y" ]; then
    name=`date +%d_%m_%y_%H_%M_%S`
    mv temp $name.status
    echo
    echo "File saved!"
    echo
else
    rm -rf temp
    echo 
fi
