#!/bin/bash

if [ "$#" -ne 0 ]
then
echo "ERROR! - THIS SCRIPT HAS NO PARAMETERS!"
else
./info.sh
fi